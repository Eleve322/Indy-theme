var time = parseInt(new Date().getTime());
localStorage.setItem("ba_msg_active", time);
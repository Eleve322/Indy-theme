document.addEventListener('DOMContentLoaded', function() {
  // 1) Cargar data de conversión
  const sizeDataScript = document.getElementById('size-conversion-data');
  const sizeConversion = sizeDataScript ? JSON.parse(sizeDataScript.textContent) : {};
  console.log('Size conversion data loaded:', sizeConversion);

  // 2) Función para mostrar equivalencias
  function showSizeEquivalences(selectedSize) {
    if (!selectedSize) return;
    console.log('Showing equivalences for size:', selectedSize);
    const equivalencesDiv = document.querySelector('.size-equivalences');

    if (equivalencesDiv && sizeConversion[selectedSize]) {
      const equivArg = document.querySelector('.equiv-arg');
      const equivUs  = document.querySelector('.equiv-us');
      const equivCm  = document.querySelector('.equiv-cm');
      const equivEu  = document.querySelector('.equiv-eu');

      if (equivArg) equivArg.textContent = sizeConversion[selectedSize].arg || selectedSize;
      if (equivUs)  equivUs.textContent  = sizeConversion[selectedSize].us  || '-';
      if (equivCm)  equivCm.textContent  = sizeConversion[selectedSize].cm  || '-';
      if (equivCm)  equivEu.textContent  = sizeConversion[selectedSize].eu  || '-';

      equivalencesDiv.style.display = 'block';
      console.log('Equivalences displayed successfully');
    } else {
      console.log('No equivalences found for size:', selectedSize);
    }
  }

  // 3) Detección del talle seleccionado actualmente (varios formatos posibles)
  function getCurrentSelectedSize() {
    // a) Swatch con clase .active
    const activeSwatch = document.querySelector('.bls__option-swatch.active');
    if (activeSwatch && activeSwatch.dataset.value) return activeSwatch.dataset.value;

    // b) Swatch item con clase .active
    const activeItem = document.querySelector('.bls_swatche-item.active');
    if (activeItem) {
      const txt = activeItem.textContent.trim();
      if (txt) return txt;
    }

    // c) Botón aria-pressed=true (algunos temas lo usan)
    const pressed = document.querySelector('.bls__option-swatch[aria-pressed="true"]');
    if (pressed && pressed.dataset.value) return pressed.dataset.value;

    // d) Fallback a un <select> de talle (Shopify nativo)
    const select = document.querySelector('select[name="Size"], select[name="Talle"]');
    if (select && select.value) return select.value;

    return null;
  }

  // 4) Inicializar una vez que existan los swatches (por si el tema los inyecta tarde)
  function initOnce() {
    const current = getCurrentSelectedSize();
    if (current) {
      showSizeEquivalences(current);
      return true;
    }
    return false;
  }

  // Retry corto: intenta varias veces en el primer segundo hasta que el tema marque la variante activa
  (function retryInit(attemptsLeft = 12) {
    if (initOnce()) return;
    if (attemptsLeft <= 0) {
      console.log('No active size detected on init.');
      return;
    }
    setTimeout(() => retryInit(attemptsLeft - 1), 80); // ~1s total
  })();

  // 5) Clicks delegados (tu lógica original)
  document.addEventListener('click', function(e) {
    const swatch = e.target.closest('.bls__option-swatch');
    if (swatch) {
      const sizeValue = swatch.dataset.value;
      console.log('BLS swatch clicked, size:', sizeValue);
      if (sizeValue) showSizeEquivalences(sizeValue);
      return; // evita doble manejo si coincide con .bls_swatche-item
    }

    const swatchItem = e.target.closest('.bls_swatche-item');
    if (swatchItem) {
      const sizeValue = swatchItem.textContent.trim();
      console.log('BLS swatch item clicked, size:', sizeValue);
      if (sizeValue) showSizeEquivalences(sizeValue);
    }
  });

  // 6) Observer para cuando el tema cambie el activo más tarde
  const observer = new MutationObserver(function(mutations) {
    for (const mutation of mutations) {
      if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
        const el = mutation.target;
        if (el.classList.contains('active')) {
          const sizeValue = el.dataset?.value || el.textContent?.trim();
          if (sizeValue) {
            console.log('Active swatch detected by observer, size:', sizeValue);
            showSizeEquivalences(sizeValue);
          }
        }
      }
    }
  });

  // Observar swatches actuales (si ya están en DOM)
  document.querySelectorAll('.bls__option-swatch, .bls_swatche-item').forEach(el => {
    observer.observe(el, { attributes: true });
  });

  // Extra: observar el contenedor por si los swatches se renderizan luego
  const container = document.querySelector('[data-product-id]') || document.body;
  const childObserver = new MutationObserver(() => {
    document.querySelectorAll('.bls__option-swatch, .bls_swatche-item').forEach(el => {
      // Si no estaba observado aún, lo sumamos:
      observer.observe(el, { attributes: true });
    });
  });
  childObserver.observe(container, { childList: true, subtree: true });

  console.log('BLS size conversion system initialized');
});

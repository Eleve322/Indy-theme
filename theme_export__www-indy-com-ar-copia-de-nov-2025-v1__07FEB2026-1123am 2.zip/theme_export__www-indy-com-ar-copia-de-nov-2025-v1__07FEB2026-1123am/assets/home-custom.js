document.addEventListener("DOMContentLoaded", function () {
    const endDate = new Date("2025-11-10T00:00:00-03:00").getTime();
    const element = document.getElementById("indy-cyber-countdown");
    if (!element) return;

    const x = setInterval(function () {
        const now = new Date().getTime();
        const dist = endDate - now;

        if (dist <= 0) {
            clearInterval(x);
            element.style.display = "none";
            return;
        }

        const h = Math.floor((dist % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const m = Math.floor((dist % (1000 * 60 * 60)) / (1000 * 60));
        const s = Math.floor((dist % (1000 * 60)) / 1000);

        const elH = document.getElementById("cdh");
        const elM = document.getElementById("cdm");
        const elS = document.getElementById("cds");

        if (elH) elH.textContent = h < 10 ? "0" + h : h;
        if (elM) elM.textContent = m < 10 ? "0" + m : m;
        if (elS) elS.textContent = s < 10 ? "0" + s : s;
    }, 1000);
});
